/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: arduino_mbsd.h
 *
 * Code generated for Simulink model 'arduino_mbsd'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Wed Jun 23 22:28:12 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_arduino_mbsd_h_
#define RTW_HEADER_arduino_mbsd_h_
#include <math.h>
#include <stddef.h>
#ifndef arduino_mbsd_COMMON_INCLUDES_
#define arduino_mbsd_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "MW_arduino_digitalio.h"
#endif                                 /* arduino_mbsd_COMMON_INCLUDES_ */

#include "arduino_mbsd_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Block signals (default storage) */
typedef struct {
  real_T disconnect;                   /* '<S1>/measurements' */
  real_T average;                      /* '<S1>/measurements' */
  real_T avg_ok;                       /* '<S1>/measurements' */
  real_T on_time;                      /* '<S1>/decide_onTime' */
  real_T off_time;                     /* '<S1>/decide_onTime' */
} B_arduino_mbsd_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  codertarget_arduinobase_block_T obj; /* '<Root>/Digital Input' */
  codertarget_arduinobase_blo_l_T obj_h;/* '<Root>/Digital Output2' */
  codertarget_arduinobase_blo_l_T obj_g;/* '<Root>/Digital Output1' */
  real_T temp;                         /* '<S1>/measurements' */
  real_T m1;                           /* '<S1>/measurements' */
  real_T m2;                           /* '<S1>/measurements' */
  real_T m3;                           /* '<S1>/measurements' */
  real_T avg_temp;                     /* '<S1>/decide_onTime' */
  uint32_T temporalCounter_i1;         /* '<S1>/measurements' */
  uint32_T temporalCounter_i1_m;       /* '<S1>/levelBlink' */
  uint16_T temporalCounter_i1_j;       /* '<S1>/pulse_generator' */
  uint8_T is_active_c1_arduino_mbsd;   /* '<S1>/pulse_generator' */
  uint8_T is_c1_arduino_mbsd;          /* '<S1>/pulse_generator' */
  uint8_T is_active_c3_arduino_mbsd;   /* '<S1>/measurements' */
  uint8_T is_c3_arduino_mbsd;          /* '<S1>/measurements' */
  uint8_T is_active_c4_arduino_mbsd;   /* '<S1>/levelBlink' */
  uint8_T is_c4_arduino_mbsd;          /* '<S1>/levelBlink' */
  uint8_T is_active_c2_arduino_mbsd;   /* '<S1>/decide_onTime' */
  uint8_T is_c2_arduino_mbsd;          /* '<S1>/decide_onTime' */
} DW_arduino_mbsd_T;

/* Parameters (default storage) */
struct P_arduino_mbsd_T_ {
  real_T DigitalInput_SampleTime;      /* Expression: 200e-6
                                        * Referenced by: '<Root>/Digital Input'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_arduino_mbsd_T {
  const char_T *errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[2];
    } TaskCounters;
  } Timing;
};

/* Block parameters (default storage) */
extern P_arduino_mbsd_T arduino_mbsd_P;

/* Block signals (default storage) */
extern B_arduino_mbsd_T arduino_mbsd_B;

/* Block states (default storage) */
extern DW_arduino_mbsd_T arduino_mbsd_DW;

/* External function called from main */
extern void arduino_mbsd_SetEventsForThisBaseStep(boolean_T *eventFlags);

/* Model entry point functions */
extern void arduino_mbsd_SetEventsForThisBaseStep(boolean_T *eventFlags);
extern void arduino_mbsd_initialize(void);
extern void arduino_mbsd_step0(void);
extern void arduino_mbsd_step1(void);
extern void arduino_mbsd_terminate(void);

/* Real-time Model object */
extern RT_MODEL_arduino_mbsd_T *const arduino_mbsd_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Display' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'arduino_mbsd'
 * '<S1>'   : 'arduino_mbsd/Subsystem'
 * '<S2>'   : 'arduino_mbsd/Subsystem/decide_onTime'
 * '<S3>'   : 'arduino_mbsd/Subsystem/levelBlink'
 * '<S4>'   : 'arduino_mbsd/Subsystem/measurements'
 * '<S5>'   : 'arduino_mbsd/Subsystem/pulse_generator'
 */
#endif                                 /* RTW_HEADER_arduino_mbsd_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
