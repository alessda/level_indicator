/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: arduino_mbsd.c
 *
 * Code generated for Simulink model 'arduino_mbsd'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Wed Jun 23 22:28:12 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "arduino_mbsd.h"
#include "arduino_mbsd_private.h"

/* Named constants for Chart: '<S1>/decide_onTime' */
#define arduino_mbsd_IN_begin          ((uint8_T)1U)
#define arduino_mbsd_IN_connected      ((uint8_T)2U)
#define arduino_mbsd_IN_disconnected   ((uint8_T)3U)
#define arduino_mbsd_IN_first_case     ((uint8_T)4U)
#define arduino_mbsd_IN_second_case    ((uint8_T)5U)

/* Named constants for Chart: '<S1>/levelBlink' */
#define arduino_mbsd_IN_begin_         ((uint8_T)1U)
#define arduino_mbsd_IN_off            ((uint8_T)2U)
#define arduino_mbsd_IN_on             ((uint8_T)3U)

/* Named constants for Chart: '<S1>/measurements' */
#define arduino_mbsd_IN_Initialization ((uint8_T)1U)
#define arduino_mbsd_IN_disconnected_c ((uint8_T)2U)
#define arduino_mbsd_IN_m1             ((uint8_T)3U)
#define arduino_mbsd_IN_m2             ((uint8_T)4U)
#define arduino_mbsd_IN_m3             ((uint8_T)5U)
#define arduino_mbsd_IN_m4             ((uint8_T)6U)
#define arduino_mbsd_IN_wait1          ((uint8_T)7U)
#define arduino_mbsd_IN_wait2          ((uint8_T)8U)
#define arduino_mbsd_IN_wait3          ((uint8_T)9U)
#define arduino_mbsd_IN_working_state  ((uint8_T)10U)

/* Named constants for Chart: '<S1>/pulse_generator' */
#define arduino_mbsd_IN_generate_trig  ((uint8_T)1U)
#define arduino_mbsd_IN_generated      ((uint8_T)2U)

/* Block signals (default storage) */
B_arduino_mbsd_T arduino_mbsd_B;

/* Block states (default storage) */
DW_arduino_mbsd_T arduino_mbsd_DW;

/* Real-time model */
static RT_MODEL_arduino_mbsd_T arduino_mbsd_M_;
RT_MODEL_arduino_mbsd_T *const arduino_mbsd_M = &arduino_mbsd_M_;
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void arduino_mbsd_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(arduino_mbsd_M, 1));
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (arduino_mbsd_M->Timing.TaskCounters.TID[1])++;
  if ((arduino_mbsd_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.0002s, 0.0s] */
    arduino_mbsd_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* Model step function for TID0 */
void arduino_mbsd_step0(void)          /* Sample time: [0.0001s, 0.0s] */
{
  {                                    /* Sample time: [0.0001s, 0.0s] */
    rate_monotonic_scheduler();
  }
}

/* Model step function for TID1 */
void arduino_mbsd_step1(void)          /* Sample time: [0.0002s, 0.0s] */
{
  int16_T rtb_on;
  int16_T rtb_trig;
  boolean_T rtb_DigitalInput_0;

  /* MATLABSystem: '<Root>/Digital Input' */
  if (arduino_mbsd_DW.obj.SampleTime != arduino_mbsd_P.DigitalInput_SampleTime)
  {
    arduino_mbsd_DW.obj.SampleTime = arduino_mbsd_P.DigitalInput_SampleTime;
  }

  rtb_DigitalInput_0 = readDigitalPin(8);

  /* Outputs for Atomic SubSystem: '<Root>/Subsystem' */
  /* Chart: '<S1>/measurements' incorporates:
   *  MATLABSystem: '<Root>/Digital Input'
   */
  if (arduino_mbsd_DW.temporalCounter_i1 < MAX_uint32_T) {
    arduino_mbsd_DW.temporalCounter_i1++;
  }

  if (arduino_mbsd_DW.is_active_c3_arduino_mbsd == 0U) {
    arduino_mbsd_DW.is_active_c3_arduino_mbsd = 1U;
    arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_Initialization;
    arduino_mbsd_DW.m1 = 0.0;
    arduino_mbsd_DW.m2 = 0.0;
    arduino_mbsd_DW.m3 = 0.0;
    arduino_mbsd_B.disconnect = 0.0;
    arduino_mbsd_B.avg_ok = 0.0;
  } else {
    switch (arduino_mbsd_DW.is_c3_arduino_mbsd) {
     case arduino_mbsd_IN_Initialization:
      arduino_mbsd_B.disconnect = 0.0;
      arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_working_state;
      arduino_mbsd_DW.temporalCounter_i1 = 0UL;
      break;

     case arduino_mbsd_IN_disconnected_c:
      arduino_mbsd_B.disconnect = 1.0;
      if (rtb_DigitalInput_0) {
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_m1;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
        arduino_mbsd_B.disconnect = 0.0;
      }
      break;

     case arduino_mbsd_IN_m1:
      arduino_mbsd_B.disconnect = 0.0;
      if (!rtb_DigitalInput_0) {
        arduino_mbsd_DW.m1 = arduino_mbsd_DW.temp;
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_wait1;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
      } else {
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      }
      break;

     case arduino_mbsd_IN_m2:
      if (!rtb_DigitalInput_0) {
        arduino_mbsd_DW.m2 = arduino_mbsd_DW.temp;
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_wait2;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
      } else {
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      }
      break;

     case arduino_mbsd_IN_m3:
      if (!rtb_DigitalInput_0) {
        arduino_mbsd_DW.m3 = arduino_mbsd_DW.temp;
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_wait3;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
      } else {
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      }
      break;

     case arduino_mbsd_IN_m4:
      if (!rtb_DigitalInput_0) {
        arduino_mbsd_B.average = (((arduino_mbsd_DW.m1 + arduino_mbsd_DW.m2) +
          arduino_mbsd_DW.m3) + arduino_mbsd_DW.temp) / 4.0;
        arduino_mbsd_B.avg_ok = 1.0;
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_working_state;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
      } else {
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      }
      break;

     case arduino_mbsd_IN_wait1:
      if (rtb_DigitalInput_0) {
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_m2;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      } else {
        if (arduino_mbsd_DW.temporalCounter_i1 >= 400UL) {
          arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_disconnected_c;
          arduino_mbsd_DW.m1 = 0.0;
          arduino_mbsd_DW.m2 = 0.0;
          arduino_mbsd_DW.m3 = 0.0;
          arduino_mbsd_B.disconnect = 1.0;
        }
      }
      break;

     case arduino_mbsd_IN_wait2:
      if (rtb_DigitalInput_0) {
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_m3;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      } else {
        if (arduino_mbsd_DW.temporalCounter_i1 >= 400UL) {
          arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_disconnected_c;
          arduino_mbsd_DW.m1 = 0.0;
          arduino_mbsd_DW.m2 = 0.0;
          arduino_mbsd_DW.m3 = 0.0;
          arduino_mbsd_B.disconnect = 1.0;
        }
      }
      break;

     case arduino_mbsd_IN_wait3:
      if (rtb_DigitalInput_0) {
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_m4;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
      } else {
        if (arduino_mbsd_DW.temporalCounter_i1 >= 400UL) {
          arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_disconnected_c;
          arduino_mbsd_DW.m1 = 0.0;
          arduino_mbsd_DW.m2 = 0.0;
          arduino_mbsd_DW.m3 = 0.0;
          arduino_mbsd_B.disconnect = 1.0;
        }
      }
      break;

     default:
      /* case IN_working_state: */
      if (rtb_DigitalInput_0) {
        arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_m1;
        arduino_mbsd_DW.temporalCounter_i1 = 0UL;
        arduino_mbsd_DW.temp = (real_T)arduino_mbsd_DW.temporalCounter_i1 *
          200.0 / 58.0;
        arduino_mbsd_B.disconnect = 0.0;
      } else {
        if (arduino_mbsd_DW.temporalCounter_i1 >= 400UL) {
          arduino_mbsd_DW.is_c3_arduino_mbsd = arduino_mbsd_IN_disconnected_c;
          arduino_mbsd_DW.m1 = 0.0;
          arduino_mbsd_DW.m2 = 0.0;
          arduino_mbsd_DW.m3 = 0.0;
          arduino_mbsd_B.disconnect = 1.0;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S1>/measurements' */

  /* Chart: '<S1>/decide_onTime' */
  if (arduino_mbsd_DW.is_active_c2_arduino_mbsd == 0U) {
    arduino_mbsd_DW.is_active_c2_arduino_mbsd = 1U;
    arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_begin;
  } else {
    switch (arduino_mbsd_DW.is_c2_arduino_mbsd) {
     case arduino_mbsd_IN_begin:
      if (arduino_mbsd_B.disconnect == 1.0) {
        arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_disconnected;
        arduino_mbsd_B.on_time = 0.5;
        arduino_mbsd_B.off_time = 0.5;
      } else {
        if (arduino_mbsd_B.avg_ok == 1.0) {
          arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_connected;
          arduino_mbsd_DW.avg_temp = arduino_mbsd_B.average;
        }
      }
      break;

     case arduino_mbsd_IN_connected:
      if ((arduino_mbsd_B.average >= 10.0) && (arduino_mbsd_B.average <= 100.0))
      {
        arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_first_case;
        arduino_mbsd_B.on_time = arduino_mbsd_B.average / 100.0 * 0.1;
        arduino_mbsd_B.off_time = 0.1 - arduino_mbsd_B.on_time;
      } else {
        arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_second_case;
        arduino_mbsd_B.on_time = 0.25;
        arduino_mbsd_B.off_time = 0.25;
      }
      break;

     case arduino_mbsd_IN_disconnected:
      if (arduino_mbsd_B.disconnect == 0.0) {
        arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_begin;
      }
      break;

     case arduino_mbsd_IN_first_case:
      if ((arduino_mbsd_B.disconnect == 1.0) || (arduino_mbsd_B.average < 10.0) ||
          (arduino_mbsd_B.average > 100.0) || (arduino_mbsd_B.average !=
           arduino_mbsd_DW.avg_temp)) {
        arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_begin;
      }
      break;

     default:
      /* case IN_second_case: */
      if (((arduino_mbsd_B.average >= 10.0) && (arduino_mbsd_B.average <= 100.0))
          || (arduino_mbsd_B.disconnect == 1.0)) {
        arduino_mbsd_DW.is_c2_arduino_mbsd = arduino_mbsd_IN_begin;
      }
      break;
    }
  }

  /* End of Chart: '<S1>/decide_onTime' */

  /* Chart: '<S1>/levelBlink' */
  if (arduino_mbsd_DW.temporalCounter_i1_m < MAX_uint32_T) {
    arduino_mbsd_DW.temporalCounter_i1_m++;
  }

  if (arduino_mbsd_DW.is_active_c4_arduino_mbsd == 0U) {
    arduino_mbsd_DW.is_active_c4_arduino_mbsd = 1U;
    arduino_mbsd_DW.is_c4_arduino_mbsd = arduino_mbsd_IN_begin_;
    rtb_on = 0;
  } else {
    switch (arduino_mbsd_DW.is_c4_arduino_mbsd) {
     case arduino_mbsd_IN_begin_:
      rtb_on = 0;
      if (arduino_mbsd_B.disconnect != arduino_mbsd_B.avg_ok) {
        arduino_mbsd_DW.is_c4_arduino_mbsd = arduino_mbsd_IN_on;
        arduino_mbsd_DW.temporalCounter_i1_m = 0UL;
        rtb_on = 1;
      }
      break;

     case arduino_mbsd_IN_off:
      rtb_on = 0;
      if (arduino_mbsd_DW.temporalCounter_i1_m >= (uint32_T)ceil
          (arduino_mbsd_B.off_time / 0.0002 - 2.0E-12)) {
        arduino_mbsd_DW.is_c4_arduino_mbsd = arduino_mbsd_IN_on;
        arduino_mbsd_DW.temporalCounter_i1_m = 0UL;
        rtb_on = 1;
      }
      break;

     default:
      /* case IN_on: */
      rtb_on = 1;
      if (arduino_mbsd_DW.temporalCounter_i1_m >= (uint32_T)ceil
          (arduino_mbsd_B.on_time / 0.0002 - 2.0E-12)) {
        arduino_mbsd_DW.is_c4_arduino_mbsd = arduino_mbsd_IN_off;
        arduino_mbsd_DW.temporalCounter_i1_m = 0UL;
        rtb_on = 0;
      }
      break;
    }
  }

  /* End of Chart: '<S1>/levelBlink' */

  /* Chart: '<S1>/pulse_generator' */
  if (arduino_mbsd_DW.temporalCounter_i1_j < 511U) {
    arduino_mbsd_DW.temporalCounter_i1_j++;
  }

  if (arduino_mbsd_DW.is_active_c1_arduino_mbsd == 0U) {
    arduino_mbsd_DW.is_active_c1_arduino_mbsd = 1U;
    arduino_mbsd_DW.is_c1_arduino_mbsd = arduino_mbsd_IN_generate_trig;
    arduino_mbsd_DW.temporalCounter_i1_j = 0U;
    rtb_trig = 1;
  } else if (arduino_mbsd_DW.is_c1_arduino_mbsd == arduino_mbsd_IN_generate_trig)
  {
    rtb_trig = 1;
    if (arduino_mbsd_DW.temporalCounter_i1_j >= 1U) {
      arduino_mbsd_DW.is_c1_arduino_mbsd = arduino_mbsd_IN_generated;
      arduino_mbsd_DW.temporalCounter_i1_j = 0U;
      rtb_trig = 0;
    }
  } else {
    /* case IN_generated: */
    rtb_trig = 0;
    if (arduino_mbsd_DW.temporalCounter_i1_j >= 300U) {
      arduino_mbsd_DW.is_c1_arduino_mbsd = arduino_mbsd_IN_generate_trig;
      arduino_mbsd_DW.temporalCounter_i1_j = 0U;
      rtb_trig = 1;
    }
  }

  /* End of Chart: '<S1>/pulse_generator' */
  /* End of Outputs for SubSystem: '<Root>/Subsystem' */

  /* MATLABSystem: '<Root>/Digital Output1' */
  writeDigitalPin(10, (uint8_T)rtb_on);

  /* MATLABSystem: '<Root>/Digital Output2' */
  writeDigitalPin(9, (uint8_T)rtb_trig);
}

/* Model initialize function */
void arduino_mbsd_initialize(void)
{
  /* Start for MATLABSystem: '<Root>/Digital Input' */
  arduino_mbsd_DW.obj.matlabCodegenIsDeleted = false;
  arduino_mbsd_DW.obj.SampleTime = arduino_mbsd_P.DigitalInput_SampleTime;
  arduino_mbsd_DW.obj.isInitialized = 1L;
  digitalIOSetup(8, 0);
  arduino_mbsd_DW.obj.isSetupComplete = true;

  /* Start for MATLABSystem: '<Root>/Digital Output1' */
  arduino_mbsd_DW.obj_g.matlabCodegenIsDeleted = false;
  arduino_mbsd_DW.obj_g.isInitialized = 1L;
  digitalIOSetup(10, 1);
  arduino_mbsd_DW.obj_g.isSetupComplete = true;

  /* Start for MATLABSystem: '<Root>/Digital Output2' */
  arduino_mbsd_DW.obj_h.matlabCodegenIsDeleted = false;
  arduino_mbsd_DW.obj_h.isInitialized = 1L;
  digitalIOSetup(9, 1);
  arduino_mbsd_DW.obj_h.isSetupComplete = true;
}

/* Model terminate function */
void arduino_mbsd_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/Digital Input' */
  if (!arduino_mbsd_DW.obj.matlabCodegenIsDeleted) {
    arduino_mbsd_DW.obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Input' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output1' */
  if (!arduino_mbsd_DW.obj_g.matlabCodegenIsDeleted) {
    arduino_mbsd_DW.obj_g.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output1' */

  /* Terminate for MATLABSystem: '<Root>/Digital Output2' */
  if (!arduino_mbsd_DW.obj_h.matlabCodegenIsDeleted) {
    arduino_mbsd_DW.obj_h.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/Digital Output2' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
