/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: arduino_mbsd_data.c
 *
 * Code generated for Simulink model 'arduino_mbsd'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Wed Jun 23 22:28:12 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "arduino_mbsd.h"
#include "arduino_mbsd_private.h"

/* Block parameters (default storage) */
P_arduino_mbsd_T arduino_mbsd_P = {
  /* Expression: 200e-6
   * Referenced by: '<Root>/Digital Input'
   */
  0.0002
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
