/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: feedback_control.c
 *
 * Code generated for Simulink model 'feedback_control'.
 *
 * Model version                  : 1.309
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Mon May 31 12:10:30 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "feedback_control.h"
#include "feedback_control_private.h"

/* Named constants for Chart: '<Root>/decide_onTime' */
#define feedback_contro_IN_disconnected ((uint8_T)3U)
#define feedback_control_IN_begin      ((uint8_T)1U)
#define feedback_control_IN_connected  ((uint8_T)2U)
#define feedback_control_IN_first_case ((uint8_T)4U)
#define feedback_control_IN_second_case ((uint8_T)5U)

/* Named constants for Chart: '<Root>/levelBlink' */
#define feedback_control_IN_begin_     ((uint8_T)1U)
#define feedback_control_IN_off        ((uint8_T)2U)
#define feedback_control_IN_on         ((uint8_T)3U)

/* Named constants for Chart: '<Root>/measurements' */
#define feedback_cont_IN_Initialization ((uint8_T)1U)
#define feedback_cont_IN_disconnected_a ((uint8_T)2U)
#define feedback_contr_IN_working_state ((uint8_T)10U)
#define feedback_control_IN_m1         ((uint8_T)3U)
#define feedback_control_IN_m2         ((uint8_T)4U)
#define feedback_control_IN_m3         ((uint8_T)5U)
#define feedback_control_IN_m4         ((uint8_T)6U)
#define feedback_control_IN_wait1      ((uint8_T)7U)
#define feedback_control_IN_wait2      ((uint8_T)8U)
#define feedback_control_IN_wait3      ((uint8_T)9U)

/* Named constants for Chart: '<Root>/pulse_generator' */
#define feedback_contr_IN_generate_trig ((uint8_T)1U)
#define feedback_control_IN_generated  ((uint8_T)2U)

/* Output and update for referenced model: 'feedback_control' */
void feedback_control(const real_T *rtu_echo, real_T *rty_level, real_T
                      *rty_trig, rtB_feedback_control *localB,
                      rtDW_feedback_control *localDW)
{
  boolean_T condIsTrue;

  /* Chart: '<Root>/measurements' */
  localDW->chartAbsoluteTimeCounter++;
  condIsTrue = ((*rtu_echo) == 1.0);
  if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2)) {
    localDW->durationLastReferenceTick_2 = localDW->chartAbsoluteTimeCounter;
  }

  localDW->condWasTrueAtLastTimeStep_2 = condIsTrue;
  condIsTrue = ((*rtu_echo) == 1.0);
  if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2_b)) {
    localDW->durationLastReferenceTick_2_j = localDW->chartAbsoluteTimeCounter;
  }

  localDW->condWasTrueAtLastTimeStep_2_b = condIsTrue;
  condIsTrue = ((*rtu_echo) == 1.0);
  if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2_c)) {
    localDW->durationLastReferenceTick_2_g = localDW->chartAbsoluteTimeCounter;
  }

  localDW->condWasTrueAtLastTimeStep_2_c = condIsTrue;
  condIsTrue = ((*rtu_echo) == 1.0);
  if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2_o)) {
    localDW->durationLastReferenceTick_2_m = localDW->chartAbsoluteTimeCounter;
  }

  localDW->condWasTrueAtLastTimeStep_2_o = condIsTrue;
  if (localDW->temporalCounter_i1 < 131071U) {
    localDW->temporalCounter_i1++;
  }

  /* Gateway: measurements */
  /* During: measurements */
  if (localDW->is_active_c3_feedback_control == 0U) {
    /* Entry: measurements */
    localDW->chartAbsoluteTimeCounter = 0;
    localDW->is_active_c3_feedback_control = 1U;

    /* Entry Internal: measurements */
    /* Transition: '<S3>:2' */
    localDW->is_c3_feedback_control = feedback_cont_IN_Initialization;

    /* Entry 'Initialization': '<S3>:1' */
    localDW->m1 = 0.0;
    localDW->m2 = 0.0;
    localDW->m3 = 0.0;
    localB->disconnect = 0.0;
    localB->avg_ok = 0.0;
  } else {
    switch (localDW->is_c3_feedback_control) {
     case feedback_cont_IN_Initialization:
      localB->disconnect = 0.0;

      /* During 'Initialization': '<S3>:1' */
      /* Transition: '<S3>:73' */
      localDW->is_c3_feedback_control = feedback_contr_IN_working_state;
      localDW->temporalCounter_i1 = 0U;
      break;

     case feedback_cont_IN_disconnected_a:
      localB->disconnect = 1.0;

      /* During 'disconnected': '<S3>:97' */
      if ((*rtu_echo) == 1.0) {
        /* Transition: '<S3>:100' */
        localDW->durationLastReferenceTick_2_j =
          localDW->chartAbsoluteTimeCounter;
        localDW->is_c3_feedback_control = feedback_control_IN_m1;

        /* Entry 'm1': '<S3>:3' */
        localDW->temp = 0.0;
        localB->disconnect = 0.0;
        localDW->condWasTrueAtLastTimeStep_2_b = true;
      }
      break;

     case feedback_control_IN_m1:
      localB->disconnect = 0.0;

      /* During 'm1': '<S3>:3' */
      if ((*rtu_echo) == 0.0) {
        /* Transition: '<S3>:76' */
        /* Exit 'm1': '<S3>:3' */
        localDW->m1 = localDW->temp;
        localDW->is_c3_feedback_control = feedback_control_IN_wait1;
        localDW->temporalCounter_i1 = 0U;
      } else {
        condIsTrue = ((*rtu_echo) == 1.0);
        if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2_b)) {
          localDW->durationLastReferenceTick_2_j =
            localDW->chartAbsoluteTimeCounter;
        }

        localDW->condWasTrueAtLastTimeStep_2_b = condIsTrue;
        localDW->temp = ((real_T)(localDW->chartAbsoluteTimeCounter -
          localDW->durationLastReferenceTick_2_j)) / 58.0;
      }
      break;

     case feedback_control_IN_m2:
      /* During 'm2': '<S3>:24' */
      if ((*rtu_echo) == 0.0) {
        /* Transition: '<S3>:34' */
        /* Exit 'm2': '<S3>:24' */
        localDW->m2 = localDW->temp;
        localDW->is_c3_feedback_control = feedback_control_IN_wait2;
        localDW->temporalCounter_i1 = 0U;
      } else {
        condIsTrue = ((*rtu_echo) == 1.0);
        if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2)) {
          localDW->durationLastReferenceTick_2 =
            localDW->chartAbsoluteTimeCounter;
        }

        localDW->condWasTrueAtLastTimeStep_2 = condIsTrue;
        localDW->temp = ((real_T)(localDW->chartAbsoluteTimeCounter -
          localDW->durationLastReferenceTick_2)) / 58.0;
      }
      break;

     case feedback_control_IN_m3:
      /* During 'm3': '<S3>:33' */
      if ((*rtu_echo) == 0.0) {
        /* Transition: '<S3>:39' */
        /* Exit 'm3': '<S3>:33' */
        localDW->m3 = localDW->temp;
        localDW->is_c3_feedback_control = feedback_control_IN_wait3;
        localDW->temporalCounter_i1 = 0U;
      } else {
        condIsTrue = ((*rtu_echo) == 1.0);
        if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2_c)) {
          localDW->durationLastReferenceTick_2_g =
            localDW->chartAbsoluteTimeCounter;
        }

        localDW->condWasTrueAtLastTimeStep_2_c = condIsTrue;
        localDW->temp = ((real_T)(localDW->chartAbsoluteTimeCounter -
          localDW->durationLastReferenceTick_2_g)) / 58.0;
      }
      break;

     case feedback_control_IN_m4:
      /* During 'm4': '<S3>:35' */
      if ((*rtu_echo) == 0.0) {
        /* Transition: '<S3>:93' */
        /* Exit 'm4': '<S3>:35' */
        localB->average = (((localDW->m1 + localDW->m2) + localDW->m3) +
                           localDW->temp) / 4.0;
        localB->avg_ok = 1.0;
        localDW->is_c3_feedback_control = feedback_contr_IN_working_state;
        localDW->temporalCounter_i1 = 0U;
      } else {
        condIsTrue = ((*rtu_echo) == 1.0);
        if ((!condIsTrue) || (!localDW->condWasTrueAtLastTimeStep_2_o)) {
          localDW->durationLastReferenceTick_2_m =
            localDW->chartAbsoluteTimeCounter;
        }

        localDW->condWasTrueAtLastTimeStep_2_o = condIsTrue;
        localDW->temp = ((real_T)(localDW->chartAbsoluteTimeCounter -
          localDW->durationLastReferenceTick_2_m)) / 58.0;
      }
      break;

     case feedback_control_IN_wait1:
      /* During 'wait1': '<S3>:29' */
      if ((*rtu_echo) == 1.0) {
        /* Transition: '<S3>:82' */
        localDW->durationLastReferenceTick_2 = localDW->chartAbsoluteTimeCounter;
        localDW->is_c3_feedback_control = feedback_control_IN_m2;

        /* Entry 'm2': '<S3>:24' */
        localDW->temp = 0.0;
        localDW->condWasTrueAtLastTimeStep_2 = true;
      } else {
        if (localDW->temporalCounter_i1 >= 80000U) {
          /* Transition: '<S3>:84' */
          localDW->is_c3_feedback_control = feedback_cont_IN_disconnected_a;

          /* Entry 'disconnected': '<S3>:97' */
          localDW->m1 = 0.0;
          localDW->m2 = 0.0;
          localDW->m3 = 0.0;
          localB->disconnect = 1.0;
        }
      }
      break;

     case feedback_control_IN_wait2:
      /* During 'wait2': '<S3>:31' */
      if ((*rtu_echo) == 1.0) {
        /* Transition: '<S3>:32' */
        localDW->durationLastReferenceTick_2_g =
          localDW->chartAbsoluteTimeCounter;
        localDW->is_c3_feedback_control = feedback_control_IN_m3;

        /* Entry 'm3': '<S3>:33' */
        localDW->temp = 0.0;
        localDW->condWasTrueAtLastTimeStep_2_c = true;
      } else {
        if (localDW->temporalCounter_i1 >= 80000U) {
          /* Transition: '<S3>:83' */
          localDW->is_c3_feedback_control = feedback_cont_IN_disconnected_a;

          /* Entry 'disconnected': '<S3>:97' */
          localDW->m1 = 0.0;
          localDW->m2 = 0.0;
          localDW->m3 = 0.0;
          localB->disconnect = 1.0;
        }
      }
      break;

     case feedback_control_IN_wait3:
      /* During 'wait3': '<S3>:36' */
      if ((*rtu_echo) == 1.0) {
        /* Transition: '<S3>:37' */
        localDW->durationLastReferenceTick_2_m =
          localDW->chartAbsoluteTimeCounter;
        localDW->is_c3_feedback_control = feedback_control_IN_m4;

        /* Entry 'm4': '<S3>:35' */
        localDW->temp = 0.0;
        localDW->condWasTrueAtLastTimeStep_2_o = true;
      } else {
        if (localDW->temporalCounter_i1 >= 80000U) {
          /* Transition: '<S3>:66' */
          localDW->is_c3_feedback_control = feedback_cont_IN_disconnected_a;

          /* Entry 'disconnected': '<S3>:97' */
          localDW->m1 = 0.0;
          localDW->m2 = 0.0;
          localDW->m3 = 0.0;
          localB->disconnect = 1.0;
        }
      }
      break;

     default:
      /* During 'working_state': '<S3>:72' */
      if ((*rtu_echo) == 1.0) {
        /* Transition: '<S3>:75' */
        localDW->durationLastReferenceTick_2_j =
          localDW->chartAbsoluteTimeCounter;
        localDW->is_c3_feedback_control = feedback_control_IN_m1;

        /* Entry 'm1': '<S3>:3' */
        localDW->temp = 0.0;
        localB->disconnect = 0.0;
        localDW->condWasTrueAtLastTimeStep_2_b = true;
      } else {
        if (localDW->temporalCounter_i1 >= 80000U) {
          /* Transition: '<S3>:90' */
          localDW->is_c3_feedback_control = feedback_cont_IN_disconnected_a;

          /* Entry 'disconnected': '<S3>:97' */
          localDW->m1 = 0.0;
          localDW->m2 = 0.0;
          localDW->m3 = 0.0;
          localB->disconnect = 1.0;
        }
      }
      break;
    }
  }

  /* End of Chart: '<Root>/measurements' */

  /* Chart: '<Root>/decide_onTime' */
  /* Gateway: decide_onTime */
  /* During: decide_onTime */
  if (localDW->is_active_c2_feedback_control == 0U) {
    /* Entry: decide_onTime */
    localDW->is_active_c2_feedback_control = 1U;

    /* Entry Internal: decide_onTime */
    /* Transition: '<S1>:3' */
    localDW->is_c2_feedback_control = feedback_control_IN_begin;

    /* Entry 'begin': '<S1>:2' */
  } else {
    switch (localDW->is_c2_feedback_control) {
     case feedback_control_IN_begin:
      /* During 'begin': '<S1>:2' */
      if (localB->disconnect == 1.0) {
        /* Transition: '<S1>:10' */
        localDW->is_c2_feedback_control = feedback_contro_IN_disconnected;

        /* Entry 'disconnected': '<S1>:9' */
        localB->on_time = 0.5;
      } else {
        if ((localB->disconnect == 0.0) && (localB->avg_ok == 1.0)) {
          /* Transition: '<S1>:35' */
          localDW->is_c2_feedback_control = feedback_control_IN_connected;

          /* Entry 'connected': '<S1>:34' */
          localDW->avg_temp = localB->average;
        }
      }
      break;

     case feedback_control_IN_connected:
      /* During 'connected': '<S1>:34' */
      if ((localB->average >= 10.0) && (localB->average <= 100.0)) {
        /* Transition: '<S1>:5' */
        localDW->is_c2_feedback_control = feedback_control_IN_first_case;

        /* Entry 'first_case': '<S1>:4' */
        localB->on_time = (localB->average / 100.0) * 0.1;
      } else {
        if ((localB->average < 10.0) || (localB->average > 100.0)) {
          /* Transition: '<S1>:8' */
          localDW->is_c2_feedback_control = feedback_control_IN_second_case;

          /* Entry 'second_case': '<S1>:6' */
          localB->on_time = 1.0;
        }
      }
      break;

     case feedback_contro_IN_disconnected:
      /* During 'disconnected': '<S1>:9' */
      if (localB->disconnect == 0.0) {
        /* Transition: '<S1>:15' */
        localDW->is_c2_feedback_control = feedback_control_IN_begin;

        /* Entry 'begin': '<S1>:2' */
      }
      break;

     case feedback_control_IN_first_case:
      /* During 'first_case': '<S1>:4' */
      if ((((localB->disconnect == 1.0) || (localB->average < 10.0)) ||
           (localB->average > 100.0)) || (localB->average != localDW->avg_temp))
      {
        /* Transition: '<S1>:13' */
        localDW->is_c2_feedback_control = feedback_control_IN_begin;

        /* Entry 'begin': '<S1>:2' */
      }
      break;

     default:
      /* During 'second_case': '<S1>:6' */
      if (((localB->average >= 10.0) && (localB->average <= 100.0)) ||
          (localB->disconnect == 1.0)) {
        /* Transition: '<S1>:26' */
        localDW->is_c2_feedback_control = feedback_control_IN_begin;

        /* Entry 'begin': '<S1>:2' */
      }
      break;
    }
  }

  /* End of Chart: '<Root>/decide_onTime' */

  /* Chart: '<Root>/levelBlink' */
  if (localDW->temporalCounter_i1_f < MAX_uint32_T) {
    localDW->temporalCounter_i1_f++;
  }

  /* Gateway: levelBlink */
  /* During: levelBlink */
  if (localDW->is_active_c4_feedback_control == 0U) {
    /* Entry: levelBlink */
    localDW->is_active_c4_feedback_control = 1U;

    /* Entry Internal: levelBlink */
    /* Transition: '<S2>:2' */
    localDW->is_c4_feedback_control = feedback_control_IN_begin_;

    /* Entry 'begin_': '<S2>:9' */
    *rty_level = 0.0;
  } else {
    switch (localDW->is_c4_feedback_control) {
     case feedback_control_IN_begin_:
      *rty_level = 0.0;

      /* During 'begin_': '<S2>:9' */
      if ((localB->avg_ok == 1.0) || (localB->disconnect == 1.0)) {
        /* Transition: '<S2>:10' */
        localDW->is_c4_feedback_control = feedback_control_IN_on;
        localDW->temporalCounter_i1_f = 0U;

        /* Entry 'on': '<S2>:1' */
        *rty_level = 1.0;
      }
      break;

     case feedback_control_IN_off:
      /* During 'off': '<S2>:4' */
      /* Transition: '<S2>:6' */
      localDW->is_c4_feedback_control = feedback_control_IN_on;
      localDW->temporalCounter_i1_f = 0U;

      /* Entry 'on': '<S2>:1' */
      *rty_level = 1.0;
      break;

     default:
      *rty_level = 1.0;

      /* During 'on': '<S2>:1' */
      if (localDW->temporalCounter_i1_f >= ((uint32_T)ceil((localB->on_time /
             1.0E-6) - 1.0E-14))) {
        /* Transition: '<S2>:5' */
        localDW->is_c4_feedback_control = feedback_control_IN_off;

        /* Entry 'off': '<S2>:4' */
        *rty_level = 0.0;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/levelBlink' */

  /* Chart: '<Root>/pulse_generator' */
  if (localDW->temporalCounter_i1_o < 65535U) {
    localDW->temporalCounter_i1_o++;
  }

  /* Gateway: pulse_generator */
  /* During: pulse_generator */
  if (localDW->is_active_c1_feedback_control == 0U) {
    /* Entry: pulse_generator */
    localDW->is_active_c1_feedback_control = 1U;

    /* Entry Internal: pulse_generator */
    /* Transition: '<S4>:7' */
    localDW->is_c1_feedback_control = feedback_contr_IN_generate_trig;
    localDW->temporalCounter_i1_o = 0U;

    /* Entry 'generate_trig': '<S4>:6' */
    *rty_trig = 1.0;
  } else if (localDW->is_c1_feedback_control == feedback_contr_IN_generate_trig)
  {
    *rty_trig = 1.0;

    /* During 'generate_trig': '<S4>:6' */
    if (localDW->temporalCounter_i1_o >= 10U) {
      /* Transition: '<S4>:10' */
      localDW->is_c1_feedback_control = feedback_control_IN_generated;
      localDW->temporalCounter_i1_o = 0U;

      /* Entry 'generated': '<S4>:9' */
      *rty_trig = 0.0;
    }
  } else {
    *rty_trig = 0.0;

    /* During 'generated': '<S4>:9' */
    if (localDW->temporalCounter_i1_o >= 60000U) {
      /* Transition: '<S4>:12' */
      localDW->is_c1_feedback_control = feedback_contr_IN_generate_trig;
      localDW->temporalCounter_i1_o = 0U;

      /* Entry 'generate_trig': '<S4>:6' */
      *rty_trig = 1.0;
    }
  }

  /* End of Chart: '<Root>/pulse_generator' */
}

/* Model initialize function */
void feedback_control_initialize(const char_T **rt_errorStatus,
  RT_MODEL_feedback_control *const feedback_control_M)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatusPointer(feedback_control_M, rt_errorStatus);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
